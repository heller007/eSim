#!/bin/bash 

nghdl="nghdl-simulator"
ghdl="ghdl-0.37"
verilator="verilator-4.210"
llvm_version="9"
config_dir="$HOME/.nghdl"
src_dir=`pwd`

# Function to handle errors
error_exit() {
    echo -e "\n\nError! Kindly resolve above error(s) and try again."
    echo -e "\nAborting Installation...\n"
    exit 1
}

# Function to install dependencies
function installDependency {
    echo "Installing required dependencies..."

    sudo apt update
    sudo apt install -y build-essential cmake git python3 python3-pip \
        zlib1g-dev libssl-dev libxml2-dev libgmp-dev \
        make gnat clang libcanberra-gtk-module libcanberra-gtk3-module libxaw7 libxaw7-dev

    echo "Installing LLVM-${llvm_version} from source..."
    if [ ! -d "llvm-${llvm_version}.0.src" ]; then
        wget https://releases.llvm.org/9.0.0/llvm-9.0.0.src.tar.xz
        tar -xf llvm-9.0.0.src.tar.xz
    fi

    # Create a build directory
    mkdir -p build
    cd build

    # Configure the LLVM build
    cmake ../llvm-9.0.0.src -G "Unix Makefiles" || error_exit
    echo "Building LLVM..."
    make -j$(nproc) || error_exit
    sudo make install || error_exit

    cd ..
}

# Function to install GHDL
function installGHDL {   
    echo "Installing GHDL..."
    tar -xJf $ghdl.tar.xz
    cd $ghdl/
    echo "Configuring GHDL..."
    chmod +x configure
    ./configure --with-llvm-config=/usr/bin/llvm-config-${llvm_version}
    make || error_exit
    sudo make install || error_exit
    echo "GHDL installed successfully."
    cd ..
}

# Function to install Verilator
function installVerilator {   
    echo "Installing Verilator..."
    tar -xJf $verilator.tar.xz
    cd $verilator
    chmod +x configure
    ./configure
    make -j$(nproc) || error_exit
    sudo make install || error_exit
    echo "Verilator installed successfully."
    cd ..
}

# Main installation function
function installNGHDL {
    echo "Installing NGHDL..."
    tar -xJf nghdl-source.tar.xz -C $HOME
    mv $HOME/nghdl-source $HOME/$nghdl
    cd $HOME/$nghdl/release
    ./configure --enable-xspice --disable-debug --prefix=$HOME/$nghdl/install_dir/
    make -j$(nproc) || error_exit
    make install || error_exit
    echo "NGHDL installed successfully."
}

# Script starts here
if [ "$#" -eq 1 ]; then
    option=$1
else
    echo "USAGE : ./install-nghdl.sh --install"
    exit 1
fi

if [ "$option" == "--install" ]; then
    installDependency
    installGHDL
    installVerilator
    installNGHDL
else 
    echo "Please select the proper operation."
    echo "--install"
fi
